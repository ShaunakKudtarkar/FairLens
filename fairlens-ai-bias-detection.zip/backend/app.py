from flask import Flask
from routes.upload import upload_bp
from routes.bias import bias_bp
from routes.training import training_bp
from routes.explainability import explain_bp

app = Flask(__name__)

app.register_blueprint(upload_bp)
app.register_blueprint(bias_bp)
app.register_blueprint(training_bp)
app.register_blueprint(explain_bp)

if __name__ == "__main__":
    app.run(debug=True)
