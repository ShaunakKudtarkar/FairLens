from flask import Blueprint, request, jsonify
import pandas as pd

upload_bp = Blueprint("upload", __name__)
df = None

@upload_bp.route("/upload", methods=["POST"])
def upload():
    global df
    file = request.files["file"]
    df = pd.read_csv(file)

    return jsonify({
        "rows": len(df),
        "columns": list(df.columns)
    })
