from flask import Blueprint, jsonify

bias_bp = Blueprint("bias", __name__)

@bias_bp.route("/bias", methods=["POST"])
def bias():
    return jsonify({
        "statistical_parity": 0.19,
        "disparate_impact": 0.37
    })
