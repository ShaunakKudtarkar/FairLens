from flask import Blueprint, jsonify

training_bp = Blueprint("training", __name__)

@training_bp.route("/train", methods=["POST"])
def train():
    return jsonify({"message": "Model trained"})
