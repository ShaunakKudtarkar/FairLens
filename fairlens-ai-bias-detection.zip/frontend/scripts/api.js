const BASE_URL = "http://127.0.0.1:5000";

async function uploadFile() {
  const file = document.getElementById("fileInput").files[0];
  const formData = new FormData();
  formData.append("file", file);

  const res = await fetch(BASE_URL + "/upload", {
    method: "POST",
    body: formData
  });

  display(await res.json());
}

async function runBias() {
  const res = await fetch(BASE_URL + "/bias", { method: "POST" });
  display(await res.json());
}

async function trainModel() {
  const res = await fetch(BASE_URL + "/train", { method: "POST" });
  display(await res.json());
}

async function explainModel() {
  const res = await fetch(BASE_URL + "/explain", { method: "POST" });
  display(await res.json());
}