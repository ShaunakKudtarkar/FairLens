function display(data) {
  document.getElementById("output").innerText =
    JSON.stringify(data, null, 2);
}